---
description: Repository Information Overview
alwaysApply: true
---

# M'Boost Information

## Summary
M'Boost is a premium juice bar web application allowing users to create custom natural juices, browse health tips, and place orders for delivery in Mahajanga. It features a complete customer-facing interface and a comprehensive administrative back-office.

## Structure
- **admin/**: Administrative dashboard and management modules (orders, clients, ingredients, ads, settings).
- **api/**: Backend endpoints for client-side operations (cart management).
- **assets/**: Static resources including CSS, JavaScript, and images.
- **auth/**: Authentication logic for both users and administrators.
- **client/**: Customer-specific pages (profile, order history, custom juice creator, cart, checkout).
- **config/**: Core configuration files (database credentials, app constants).
- **database/**: SQL schema and database initialization scripts.
- **includes/**: Shared PHP components, database connection singleton, and helper functions.
- **scripts/**: Utility scripts (e.g., image conversion).
- **uploads/**: Destination for user and admin-uploaded files (images, PDFs).

## Language & Runtime
**Language**: PHP  
**Version**: PHP 8.x (implied by union types and modern features)  
**Database**: MySQL / MariaDB  
**Web Server**: Compatible with Apache (.htaccess present)  

## Dependencies
**Main Dependencies**:
- **PDO**: Database abstraction and security.
- **Tailwind CSS**: UI styling (inferred from helper functions).
- **Session**: State management for carts and authentication.

## Build & Installation
1.  Import `database/schema.sql` into a MySQL/MariaDB database.
2.  Configure database credentials in `config/config.php`.
3.  Ensure the `uploads/` directory and its subdirectories are writable by the web server.
4.  Default Admin: `admin@mboost.mg` / `Admin@1234` (Change immediately after login).

## Main Files & Resources
- **index.php**: Main landing page and entry point.
- **config/config.php**: Global configuration and business logic constants.
- **includes/db.php**: Centralized PDO connection management.
- **includes/functions.php**: Core utility functions (security, formatting, file uploads).
- **database/schema.sql**: Complete database structure and seed data.
- **client/creer-jus.php**: Custom juice builder interface.

## Testing & Validation
- **Validation**: Server-side validation in PHP for forms and file uploads (MIME type checking).
- **Security**: CSRF protection implemented via `generateCSRF()` and `verifyCSRF()`. Password hashing using `bcrypt`.
- **Manual Verification**: Test scripts like `test_upload.pdf` suggest manual verification of upload capabilities.
